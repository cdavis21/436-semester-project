package com.worldstars.semesterproject436;

public class Purchase {
	private String name;
	private String cost;
	
	public Purchase() {
		name = "n/a";
		cost = "n/a";
	}
	
	public Purchase(String name, String cost) {
		this.name = name;
		this.cost = cost;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setCost(String cost) {
		this.cost = cost;
	}
	
	public String getCost() {
		return this.cost;
	}
}
